#ifndef analogPin_h
#define analogPin_h

#include <Arduino.h>

class AnalogPin {
    private: 
        int _pinNum;
        volatile byte *_PORT;
        volatile byte *_PIN;
        volatile byte *_DDR;
        byte _notPORT;

        volatile byte *_ADMUX;
        volatile byte *_ADCSRA;
        volatile byte *_ADCSRB;
        volatile byte *_ADCH;
        volatile byte *_ADCL;   

    public:
        AnalogPin(uint8_t pin);

        void setPin();                  // Preliminary logic to bind pin to object
        int getPin();                   // NOT IMPLEMENTED
        void setPinMode(int mode);      // Set pin mode OUTPUT/INPUT/ADC                                                Setting mode to ADC disables digital output, and sets pinmode to input
        void on();                      // Set bound pin HIGH                                                           On the Atmega 2560, Analog pins can be used for digital I/O as well.
        void off();                     // Set bound pin LOW                                                            On the Atmega 2560, Analog pins can be used for digital I/O as well.
        void invert();                  // Invert bound pin HIGH/LOW                                                   On the Atmega 2560, Analog pins can be used for digital I/O as well.

        void enableADC();               // Enables ADC on bound pin
        void disableADC();              // Disables ADC
        int checkADC();                 // Checks if ADC is enabled via register, returns HIGH if enabled, returns LOW if disabled
        int checkADCEnable();           // Checks if ADC is enabled via variable, NOT IMPLEMENTED
        int readADC();                  // Starts ADC, returns value
        void setADC();                  // Sets ADC mux train to bound pin              
};

#endif