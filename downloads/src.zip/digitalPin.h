#ifndef digitalPin_h
#define digitalPin_h

#include <Arduino.h>

class DigitalPin {
  private:
    uint8_t _pinNum;
    volatile byte *_PORT;
    volatile byte *_PIN;
    volatile byte *_DDR;
    byte _notPORT;

    volatile byte *_TCCRA;
    volatile byte *_TCCRB;
    volatile byte *_TCNT;
    volatile byte *_TCNTH;
    volatile byte *_TCNTL;
    volatile byte *_OCRA;
    volatile byte *_OCRB;
    volatile byte *_OCRC;
    volatile byte *_OCRAH;
    volatile byte *_OCRAL;
    volatile byte *_OCRBH;
    volatile byte *_OCRBL;
    volatile byte *_OCRCH;
    volatile byte *_OCRCL;
    volatile byte *_ICRH;
    volatile byte *_ICRL;
    volatile byte *_TIMSK;
    
    int read;

  public:
    DigitalPin(uint8_t pin);

    void setTCCRA(uint8_t value);
    void setTCCRB(uint8_t value);
    void setTCNT(uint16_t value);
    void setOCRA(uint16_t value);
    void setOCRB(uint16_t value); 
    void setOCRC(uint16_t value);
    void setICR(uint16_t value);
    void factorOCRA(float value);
    void factorOCRB(float value);
    void factorOCRC(float value);
    void setDutyCycle(float cycle);

    void setTIMSK(uint8_t value);

    void setPin();                   // Preliminary logic to bind pin to object
    int getPin();                    // NOT IMPLEMENTED
    void setPinMode(int mode);       // Set pin mode OUTPUT/INPUT
    void on();                       // Set bound pin HIGH
    void off();                      // Set bound pin LOW
    void invert();                   // Invert bound pin HIGH/LOW
    void pulse(float duration);      // Generates a single pulse of length duration ms

    int getPinNum() const;           // Return bound pin number
    void setPinNum(int pin);         // Re-bind object pin number

};
#endif