#include "analogPin.h"

#define ADMUX_ADDRESS  0x7C
#define ADCSRA_ADDRESS 0x7A
#define ADCSRB_ADDRESS 0x7B
#define ADCH_ADDRESS   0x79
#define ADCL_ADDRESS   0x78

#define PORTF_ADDRESS  0x31
#define PINF_ADDRESS   0x2F
#define DDRF_ADDRESS   0x30

#define PORTK_ADDRESS  0x108
#define PINK_ADDRESS   0x106
#define DDRK_ADDRESS   0x104

AnalogPin::AnalogPin(uint8_t pin) {
  _pinNum = pin;
  _ADMUX = (volatile byte*)(ADMUX_ADDRESS);
  _ADCSRA = (volatile byte*)(ADCSRA_ADDRESS);
  _ADCSRB = (volatile byte*)(ADCSRB_ADDRESS);
  _ADCH = (volatile byte*)(ADCH_ADDRESS);
  _ADCL = (volatile byte*)(ADCL_ADDRESS);
  switch(_pinNum) {
    case A0: case A1: case A2: case A3: case A4: case A5: case A6: case A7:
        ADMUX = (ADMUX & 0xF8) | ((_pinNum - 7) & 0x07);      
    break;

    case A8: case A9: case A10: case A11: case A12: case A13: case A14: case A15:
        ADMUX = (ADMUX & 0xF8) | ((_pinNum - 15) & 0x07);   
        ADCSRB |= (1 << 3);
    break;
  }

  *_ADCSRA = 0b00000111;   // Set prescalar to 128
  *_ADMUX |= (1 << REFS0); // Set reference to Avcc

  switch(_pinNum) {
    // PORT A
    case A0: case A1: case A2: case A3: case A4: case A5: case A6: case A7: 
      // 29, 28, 27, 26, 25, 24, 23, 22
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTF_ADDRESS);
      _PIN = (volatile byte*)(PINF_ADDRESS);
      _DDR = (volatile byte*)(DDRF_ADDRESS);
    break;

    // PORT B
    case A8: case A9: case A10: case A11: case A12: case A13: case A14: case A15:
      // 13, 12, 11, 10, 50, 51, 52, 53
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTK_ADDRESS);
      _PIN = (volatile byte*)(PINK_ADDRESS);
      _DDR = (volatile byte*)(DDRK_ADDRESS);
    break;
  }
}

int AnalogPin::readADC() {
    *_ADCSRA |= (1 << ADSC);
    while (*_ADCSRA & (1 << ADSC));
    int value = *_ADCL | (*_ADCH << 8);
    return value;
}

int AnalogPin::checkADC() {
  return (*_ADCSRA & 0b10000000) ? HIGH : LOW;
}

void AnalogPin::enableADC() {
  *_ADCSRA |= 0b10000000;
}

void AnalogPin::disableADC() {
  *_ADCSRA &= 0b01111111;
}

void AnalogPin::setADC() {
  disableADC();
  switch(_pinNum) {
    case A0: case A1: case A2: case A3: case A4: case A5: case A6: case A7:
        ADMUX = (ADMUX & 0xF8) | ((_pinNum - 7) & 0x07);      
    break;

    case A8: case A9: case A10: case A11: case A12: case A13: case A14: case A15:
        ADMUX = (ADMUX & 0xF8) | ((_pinNum - 15) & 0x07);   
        ADCSRB |= (1 << 3);
    break;
  }
  enableADC();
}

void AnalogPin::setPin() {
  switch(_pinNum) {
    case A0: case A8:
      *_PORT = 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case A1: case A9:
      *_PORT = 0b00000010;
      _notPORT = ~*_PORT;
    break;

    case A2: case A10:
      *_PORT = 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case A3: case A11:
      *_PORT = 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case A4: case A12:
      *_PORT = 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case A5: case A13:
      *_PORT = 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case A6: case A14:
      *_PORT = 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case A7: case A15:
      *_PORT = 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}

void AnalogPin::setPinMode(int mode) {
  if(mode == ADC) {
    switch(_pinNum) {
      case A0: case A8:
        *_DDR &= 0b11111110;
        *_PORT &= 0b11111110;       
      break;

      case A1: case A9:
        *_DDR &= 0b11111101;
        *_PORT &= 0b11111101; 
      break;

      case A2: case A10:
        *_DDR &= 0b11111011;
        *_PORT &= 0b11111011;
      break;

      case A3: case A11:
        *_DDR &= 0b11110111;
        *_PORT &= 0b11110111;
      break;

      case A4: case A12:
        *_DDR &= 0b11101111;
        *_PORT &= 0b11101111;
      break;

      case A5: case A13:
        *_DDR &= 0b11011111;
        *_PORT &= 0b11011111;
      break;

      case A6: case A14:
        *_DDR &= 0b10111111;
        *_PORT &= 0b10111111;
      break;

      case A7: case A15:
        *_DDR &= 0b01111111;
        *_PORT &= 0b01111111;
      break;
    }   
    enableADC();
  }
  else if(mode == INPUT) {
    switch(_pinNum) {
      case A0: case A8:
        *_DDR &= 0b11111110;
      break;

      case A1: case A9:
        *_DDR &= 0b11111101;
      break;

      case A2: case A10:
        *_DDR &= 0b11111011;
      break;

      case A3: case A11:
        *_DDR &= 0b11110111;
      break;

      case A4: case A12:
        *_DDR &= 0b11101111;
      break;

      case A5: case A13:
        *_DDR &= 0b11011111;
      break;

      case A6: case A14:
        *_DDR &= 0b10111111;
      break;

      case A7: case A15:
        *_DDR &= 0b01111111;
      break;
    }
  }
  else if(mode == OUTPUT) {
    disableADC();
    switch(_pinNum) {
      case A0: case A8:
        *_DDR |= 0b00000001;
      break;

      case A1: case A9:
        *_DDR |= 0b00000010;
      break;

      case A2: case A10:
        *_DDR |= 0b00000100;
      break;

      case A3: case A11:
        *_DDR |= 0b00001000;
      break;

      case A4: case A12:
        *_DDR |= 0b00010000;
      break;

      case A5: case A13:
        *_DDR |= 0b00100000;
      break;

      case A6: case A14:
        *_DDR |= 0b01000000;
      break;

      case A7: case A15:
        *_DDR |= 0b10000000;
      break;
    }
  }
}

void AnalogPin::on() {
  switch(_pinNum) {
    case A0: case A8:
      *_PORT |= 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case A1: case A9:
      *_PORT |= 0b00000010;
      _notPORT = ~*_PORT;        
    break;

    case A2: case A10:
      *_PORT |= 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case A3: case A11:
      *_PORT |= 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case A4: case A12:
      *_PORT |= 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case A5: case A13:
      *_PORT |= 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case A6: case A14:
      *_PORT |= 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case A7: case A15:
      *_PORT |= 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}

void AnalogPin::off() {
  switch(_pinNum) {
    case A0: case A8:
      *_PORT &= 0b11111110;
      _notPORT = ~*_PORT;
    break;

    case A1: case A9:
      *_PORT &= 0b11111101;
      _notPORT = ~*_PORT;        
    break;

    case A2: case A10:
      *_PORT &= 0b11111011;
      _notPORT = ~*_PORT;
    break;

    case A3: case A11:
      *_PORT &= 0b11110111;
      _notPORT = ~*_PORT;
    break;

    case A4: case A12:
      *_PORT &= 0b11101111;
      _notPORT = ~*_PORT;
    break;

    case A5: case A13:
      *_PORT &= 0b11011111;
      _notPORT = ~*_PORT;
    break;

    case A6: case A14:
      *_PORT &= 0b10111111;
      _notPORT = ~*_PORT;
    break;

    case A7: case A15:
      *_PORT &= 0b01111111;
      _notPORT = ~*_PORT;
    break;
  }
}

void AnalogPin::invert() {
  switch(_pinNum) {
    case A0: case A8:
      *_PORT ^= 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case A1: case A9:
      *_PORT ^= 0b00000010;
      _notPORT = ~*_PORT;        
    break;

    case A2: case A10:
      *_PORT ^= 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case A3: case A11:
      *_PORT ^= 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case A4: case A12:
      *_PORT ^= 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case A5: case A13:
      *_PORT ^= 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case A6: case A14:
      *_PORT ^= 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case A7: case A15:
      *_PORT ^= 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}