#include "digitalPin.h"

#define TCCR0A_ADDRESS 0x44 
#define TCCR0B_ADDRESS 0x45 
#define TCNT0_ADDRESS  0x46
#define OCR0A_ADDRESS  0x47 
#define OCR0B_ADDRESS  0x48 
#define TIMSK0_ADDRESS 0x6E 

#define TCCR2A_ADDRESS 0xB0 
#define TCCR2B_ADDRESS 0xB1 
#define TCNT2_ADDRESS  0xB2 
#define OCR2A_ADDRESS  0xB3 
#define OCR2B_ADDRESS  0xB4 
#define TIMSK2_ADDRESS 0x70 

#define TCCR1A_ADDRESS 0x80 
#define TCCR1B_ADDRESS 0x81 
#define TCCR1C_ADDRESS 0x82
#define TCNT1H_ADDRESS 0x85 
#define TCNT1L_ADDRESS 0x84
#define OCR1AH_ADDRESS 0x89 
#define OCR1AL_ADDRESS 0x88
#define OCR1BH_ADDRESS 0x8B 
#define OCR1BL_ADDRESS 0x8A
#define OCR1CH_ADDRESS 0x8D 
#define OCR1CL_ADDRESS 0x8C
#define ICR1H_ADDRESS  0x87
#define ICR1L_ADDRESS  0x86
#define TIMSK1_ADDRESS 0x6F

#define TCCR3A_ADDRESS 0x90 
#define TCCR3B_ADDRESS 0x91 
#define TCCR3C_ADDRESS 0x92
#define TCNT3H_ADDRESS 0x95 
#define TCNT3L_ADDRESS 0x94
#define OCR3AH_ADDRESS 0x99 
#define OCR3AL_ADDRESS 0x98
#define OCR3BH_ADDRESS 0x9B 
#define OCR3BL_ADDRESS 0x9A
#define OCR3CH_ADDRESS 0x9D 
#define OCR3CL_ADDRESS 0x9C
#define ICR3H_ADDRESS  0x97
#define ICR3L_ADDRESS  0x96
#define TIMSK3_ADDRESS 0x71 

#define TCCR4A_ADDRESS 0xA0 
#define TCCR4B_ADDRESS 0xA1 
#define TCCR4C_ADDRESS 0xA2
#define TCNT4H_ADDRESS 0xA5 
#define TCNT4L_ADDRESS 0xA4
#define OCR4AH_ADDRESS 0xA9 
#define OCR4AL_ADDRESS 0xA8
#define OCR4BH_ADDRESS 0xAB 
#define OCR4BL_ADDRESS 0xAA
#define OCR4CH_ADDRESS 0xAD 
#define OCR4CL_ADDRESS 0xAC
#define ICR4H_ADDRESS  0xA7
#define ICR4L_ADDRESS  0xA6
#define TIMSK4_ADDRESS 0x72 

#define TCCR5A_ADDRESS 0x120 
#define TCCR5B_ADDRESS 0x121 
#define TCCR5C_ADDRESS 0x122
#define TCNT5H_ADDRESS 0x125 
#define TCNT5L_ADDRESS 0x124 
#define OCR5AH_ADDRESS 0x129 
#define OCR5AL_ADDRESS 0x128
#define OCR5BH_ADDRESS 0x12B 
#define OCR5BL_ADDRESS 0x12A
#define OCR5CH_ADDRESS 0x12D 
#define OCR5CL_ADDRESS 0x12C
#define ICR5H_ADDRESS  0x127
#define ICR5L_ADDRESS  0x126
#define TIMSK5_ADDRESS 0x73 

// PORTS/PINS

// DDR    Data Direction Register
// PORT   Port Data Register (HIGH/LOW)
// PIN    Input Pins Address

#define DDRA_ADDRESS   0x21
#define PORTA_ADDRESS  0x22
#define PINA_ADDRESS   0x20

#define DDRB_ADDRESS   0x24
#define PORTB_ADDRESS  0x25
#define PINB_ADDRESS   0x23

#define DDRC_ADDRESS   0x27
#define PORTC_ADDRESS  0x28
#define PINC_ADDRESS   0x26

#define DDRD_ADDRESS   0x2A
#define PORTD_ADDRESS  0x2B
#define PIND_ADDRESS   0x29

#define DDRE_ADDRESS   0x2D
#define PORTE_ADDRESS  0x2E
#define PINE_ADDRESS   0x2C

#define DDRF_ADDRESS   0x30
#define PORTF_ADDRESS  0x31
#define PINF_ADDRESS   0x2F

#define DDRG_ADDRESS   0x33
#define PORTG_ADDRESS  0x34
#define PING_ADDRESS   0x32

#define DDRH_ADDRESS   0x101
#define PORTH_ADDRESS  0x102
#define PINH_ADDRESS   0x100

#define DDRJ_ADDRESS   0x104
#define PORTJ_ADDRESS  0x105
#define PINJ_ADDRESS   0x103

#define DDRK_ADDRESS   0x107
#define PORTK_ADDRESS  0x108
#define PINK_ADDRESS   0x106

#define DDRL_ADDRESS   0x10A
#define PORTL_ADDRESS  0x10B
#define PINL_ADDRESS   0x109

DigitalPin::DigitalPin(uint8_t pin) {
  _pinNum = pin;
  pinMode(_pinNum, OUTPUT);
  digitalWrite(_pinNum, HIGH);
  switch(_pinNum) {
    // PORT A
    case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: 
      // 29, 28, 27, 26, 25, 24, 23, 22
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTA_ADDRESS);
      _PIN = (volatile byte*)(PINA_ADDRESS);
      _DDR = (volatile byte*)(DDRA_ADDRESS);
    break;

    // PORT B
    case 53: case 52: case 51: case 50: case 10: case 11: case 12: case 13: 
      // 13, 12, 11, 10, 50, 51, 52, 53
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTB_ADDRESS);
      _PIN = (volatile byte*)(PINB_ADDRESS);
      _DDR = (volatile byte*)(DDRB_ADDRESS);
    break;

    // PORT C
    case 37: case 36: case 35: case 34: case 33: case 32: case 31: case 30: 
      // 30, 31, 32, 33, 34, 35, 36, 37
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTC_ADDRESS);
      _PIN = (volatile byte*)(PINC_ADDRESS);
      _DDR = (volatile byte*)(DDRC_ADDRESS);
    break;

    // PORT D
    case 21: case 20: case 19: case 18: case 38:                            
      // 38, 00, 00, 00, 18, 19, 20, 21
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTD_ADDRESS);
      _PIN = (volatile byte*)(PIND_ADDRESS);
      _DDR = (volatile byte*)(DDRD_ADDRESS);
    break; 

    // PORT E
    case 0: case 1: case 2: case 3: case 5:                                
      // 00, 00, 3, 2, 5, 00, 1, 0
      // 7   6   5  4  3  2   1  0 
      _PORT = (volatile byte*)(PORTE_ADDRESS);
      _PIN = (volatile byte*)(PINE_ADDRESS);
      _DDR = (volatile byte*)(DDRE_ADDRESS);
    break;

    // PORT F
    // While PORT F is labeled analog, it can still be used for digital I/O
    // Handled by analog library

    // PORT G
    case 41: case 40: case 39: case 4:                                      
      // 00, 00, 4, 00, 00, 39, 40, 41
      // 7   6   5  4   3   2   1   0
      _PORT = (volatile byte*)(PORTG_ADDRESS);
      _PIN = (volatile byte*)(PING_ADDRESS);
      _DDR = (volatile byte*)(DDRG_ADDRESS);
    break;

    // PORT H
    case 17: case 16: case 6: case 7: case 8: case 9:                     
      // 00, 9, 8, 7, 6, 00, 16, 17
      // 7   6  5  4  3  2   1   0
      _PORT = (volatile byte*)(PORTH_ADDRESS);
      _PIN = (volatile byte*)(PINH_ADDRESS);
      _DDR = (volatile byte*)(DDRH_ADDRESS);
    break;

    // PORT J
    case 15: case 14:                                                   
      // 00, 00, 00, 00, 00, 00, 14, 15
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTJ_ADDRESS);
      _PIN = (volatile byte*)(PINJ_ADDRESS);
      _DDR = (volatile byte*)(DDRJ_ADDRESS);
    break;

    // PORT K
    // While PORT K is labeled analog, it can still be used for digital I/O
    // Handled by analog library

    // PORT L
    case 49: case 48: case 47: case 46: case 45: case 44: case 43: case 42: 
      // 42, 43, 44, 45, 46, 47, 48, 49
      // 7   6   5   4   3   2   1   0
      _PORT = (volatile byte*)(PORTL_ADDRESS);
      _PIN = (volatile byte*)(PINL_ADDRESS);
      _DDR = (volatile byte*)(DDRL_ADDRESS);
    break;
  }

  // *_DDR = 0b00000000;
  // *_PORT = 0b00000000;

  switch(_pinNum) {
    // TIMER ZERO
    case 4: case 13:
      _TCCRA = (volatile byte*)(TCCR0A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR0B_ADDRESS);
      _TCNT = (volatile byte*)(TCNT0_ADDRESS);
      _OCRA = (volatile byte*)(OCR0A_ADDRESS);
      _OCRB = (volatile byte*)(OCR0B_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK0_ADDRESS);
    break;

    // TIMER TWO
    case 9: case 10:            
      _TCCRA = (volatile byte*)(TCCR2A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR2B_ADDRESS);
      _TCNT = (volatile byte*)(TCNT2_ADDRESS);
      _OCRA = (volatile byte*)(OCR2A_ADDRESS);
      _OCRB = (volatile byte*)(OCR2B_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK2_ADDRESS);
    break;

    // TIMER ONE
    case 11: case 12:
      _TCCRA = (volatile byte*)(TCCR1A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR1B_ADDRESS);
      _TCNTH = (volatile byte*)(TCNT1H_ADDRESS);
      _TCNTL = (volatile byte*)(TCNT1L_ADDRESS);
      _OCRAH = (volatile byte*)(OCR1AH_ADDRESS);
      _OCRAL = (volatile byte*)(OCR1AL_ADDRESS);
      _OCRBH = (volatile byte*)(OCR1BH_ADDRESS);
      _OCRBL = (volatile byte*)(OCR1BL_ADDRESS);
      _OCRCH = (volatile byte*)(OCR1CH_ADDRESS);
      _OCRCL = (volatile byte*)(OCR1CL_ADDRESS);
      _ICRH = (volatile byte*)(ICR1H_ADDRESS);
      _ICRL = (volatile byte*)(ICR1L_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK1_ADDRESS);
    break;

    // TIMER THREE
    case 2: case 3: case 5:
      _TCCRA = (volatile byte*)(TCCR3A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR3B_ADDRESS);
      _TCNTH = (volatile byte*)(TCNT3H_ADDRESS);
      _TCNTL = (volatile byte*)(TCNT3L_ADDRESS);
      _OCRAH = (volatile byte*)(OCR3AH_ADDRESS);
      _OCRAL = (volatile byte*)(OCR3AL_ADDRESS);
      _OCRBH = (volatile byte*)(OCR3BH_ADDRESS);
      _OCRBL = (volatile byte*)(OCR3BL_ADDRESS);
      _OCRCH = (volatile byte*)(OCR3CH_ADDRESS);
      _OCRCL = (volatile byte*)(OCR3CL_ADDRESS);
      _ICRH = (volatile byte*)(ICR3H_ADDRESS);
      _ICRL = (volatile byte*)(ICR3L_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK3_ADDRESS);
    break;

    // TIMER FOUR
    case 6: case 7: case 8:
      _TCCRA = (volatile byte*)(TCCR4A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR4B_ADDRESS);
      _TCNTH = (volatile byte*)(TCNT4H_ADDRESS);
      _TCNTL = (volatile byte*)(TCNT4L_ADDRESS);
      _OCRAH = (volatile byte*)(OCR4AH_ADDRESS);
      _OCRAL = (volatile byte*)(OCR4AL_ADDRESS);
      _OCRBH = (volatile byte*)(OCR4BH_ADDRESS);
      _OCRBL = (volatile byte*)(OCR4BL_ADDRESS);
      _OCRCH = (volatile byte*)(OCR4CH_ADDRESS);
      _OCRCL = (volatile byte*)(OCR4CL_ADDRESS);
      _ICRH = (volatile byte*)(ICR4H_ADDRESS);
      _ICRL = (volatile byte*)(ICR4L_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK4_ADDRESS);
    break;

    // TIMER FIVE
    case 44: case 45: case 46:
      _TCCRA = (volatile byte*)(TCCR5A_ADDRESS);
      _TCCRB = (volatile byte*)(TCCR5B_ADDRESS);
      _TCNTH = (volatile byte*)(TCNT5H_ADDRESS);
      _TCNTL = (volatile byte*)(TCNT5L_ADDRESS);
      _OCRAH = (volatile byte*)(OCR5AH_ADDRESS);
      _OCRAL = (volatile byte*)(OCR5AL_ADDRESS);
      _OCRBH = (volatile byte*)(OCR5BH_ADDRESS);
      _OCRBL = (volatile byte*)(OCR5BL_ADDRESS);
      _OCRCH = (volatile byte*)(OCR5CH_ADDRESS);
      _OCRCL = (volatile byte*)(OCR5CL_ADDRESS);
      _ICRH = (volatile byte*)(ICR5H_ADDRESS);
      _ICRL = (volatile byte*)(ICR5L_ADDRESS);
      _TIMSK = (volatile byte*)(TIMSK5_ADDRESS);
    break;
  }
}

void DigitalPin::setPin() {
  switch(_pinNum) {
    case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
      *_PORT = 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
      *_PORT = 0b00000010;
      _notPORT = ~*_PORT;
    break;

    case 24: case 51: case 35: case 19: case 39: case 47:
      *_PORT = 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case 25: case 50: case 34: case 18: case 5: case 6: case 46:
      *_PORT = 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case 26: case 10: case 33: case 2: case 7: case 45:
      *_PORT = 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case 27: case 11: case 32: case 3: case 4: case 8: case 44:
      *_PORT = 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case 28: case 12: case 31: case 9: case 43:
      *_PORT = 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case 29: case 13: case 30: case 38: case 42:
      *_PORT = 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}

void DigitalPin::setPinMode(int mode) {
  if(mode == INPUT) {
    switch(_pinNum) {
      case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
        *_DDR &= 0b11111110;
      break;

      case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
        *_DDR &= 0b11111101;
      break;

      case 24: case 51: case 35: case 19: case 39: case 47:
        *_DDR &= 0b11111011;
      break;

      case 25: case 50: case 34: case 18: case 5: case 6: case 46:
        *_DDR &= 0b11110111;
      break;

      case 26: case 10: case 33: case 2: case 7: case 45:
        *_DDR &= 0b11101111;
      break;

      case 27: case 11: case 32: case 3: case 4: case 8: case 44:
        *_DDR &= 0b11011111;
      break;

      case 28: case 12: case 31: case 9: case 43:
        *_DDR &= 0b10111111;
      break;

      case 29: case 13: case 30: case 38: case 42:
        *_DDR &= 0b01111111;
      break;
    }
  }
  if(mode == OUTPUT) {
    switch(_pinNum) {
      case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
        *_DDR |= 0b00000001;
      break;

      case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
        *_DDR |= 0b00000010;
      break;

      case 24: case 51: case 35: case 19: case 39: case 47:
        *_DDR |= 0b00000100;
      break;

      case 25: case 50: case 34: case 18: case 5: case 6: case 46:
        *_DDR |= 0b00001000;
      break;

      case 26: case 10: case 33: case 2: case 7: case 45:
        *_DDR |= 0b00010000;
      break;

      case 27: case 11: case 32: case 3: case 4: case 8: case 44:
        *_DDR |= 0b00100000;
      break;

      case 28: case 12: case 31: case 9: case 43:
        *_DDR |= 0b01000000;
      break;

      case 29: case 13: case 30: case 38: case 42:
        *_DDR |= 0b10000000;
      break;
    }
  }
}

void DigitalPin::on() {
  switch(_pinNum) {
    case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
      *_PORT |= 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
      *_PORT |= 0b00000010;
      _notPORT = ~*_PORT;        
    break;

    case 24: case 51: case 35: case 19: case 39: case 47:
      *_PORT |= 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case 25: case 50: case 34: case 18: case 5: case 6: case 46:
      *_PORT |= 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case 26: case 10: case 33: case 2: case 7: case 45:
      *_PORT |= 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case 27: case 11: case 32: case 3: case 4: case 8: case 44:
      *_PORT |= 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case 28: case 12: case 31: case 9: case 43:
      *_PORT |= 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case 29: case 13: case 30: case 38: case 42:
      *_PORT |= 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}

void DigitalPin::off() {
  switch(_pinNum) {
    case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
      *_PORT &= 0b11111110;
      _notPORT = ~*_PORT;
    break;

    case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
      *_PORT &= 0b11111101;
      _notPORT = ~*_PORT;        
    break;

    case 24: case 51: case 35: case 19: case 39: case 47:
      *_PORT &= 0b11111011;
      _notPORT = ~*_PORT;
    break;

    case 25: case 50: case 34: case 18: case 5: case 6: case 46:
      *_PORT &= 0b11110111;
      _notPORT = ~*_PORT;
    break;

    case 26: case 10: case 33: case 2: case 7: case 45:
      *_PORT &= 0b11101111;
      _notPORT = ~*_PORT;
    break;

    case 27: case 11: case 32: case 3: case 4: case 8: case 44:
      *_PORT &= 0b11011111;
      _notPORT = ~*_PORT;
    break;

    case 28: case 12: case 31: case 9: case 43:
      *_PORT &= 0b10111111;
      _notPORT = ~*_PORT;
    break;

    case 29: case 13: case 30: case 38: case 42:
      *_PORT &= 0b01111111;
      _notPORT = ~*_PORT;
    break;
  }
}

void DigitalPin::invert() {
  switch(_pinNum) {
    case 22: case 53: case 37: case 21: case 0: case 41: case 17: case 15: case 49:
      *_PORT ^= 0b00000001;
      _notPORT = ~*_PORT;
    break;

    case 23: case 52: case 36: case 20: case 1: case 40: case 16: case 14: case 48:
      *_PORT ^= 0b00000010;
      _notPORT = ~*_PORT;        
    break;

    case 24: case 51: case 35: case 19: case 39: case 47:
      *_PORT ^= 0b00000100;
      _notPORT = ~*_PORT;
    break;

    case 25: case 50: case 34: case 18: case 5: case 6: case 46:
      *_PORT ^= 0b00001000;
      _notPORT = ~*_PORT;
    break;

    case 26: case 10: case 33: case 2: case 7: case 45:
      *_PORT ^= 0b00010000;
      _notPORT = ~*_PORT;
    break;

    case 27: case 11: case 32: case 3: case 4: case 8: case 44:
      *_PORT ^= 0b00100000;
      _notPORT = ~*_PORT;
    break;

    case 28: case 12: case 31: case 9: case 43:
      *_PORT ^= 0b01000000;
      _notPORT = ~*_PORT;
    break;

    case 29: case 13: case 30: case 38: case 42:
      *_PORT ^= 0b10000000;
      _notPORT = ~*_PORT;
    break;
  }
}

int DigitalPin::getPin() {

}

int DigitalPin::getPinNum() const {
  return _pinNum;
}

void DigitalPin::setPinNum(int pin) {
  _pinNum = pin;
}

void DigitalPin::pulse(float duration) {
  // Terrible Implementation TODO take timers in use interfering with delay into account
  on();
  delay(duration);
  off();
}

void DigitalPin::setTCCRA(uint8_t value) {
  // Set TCCRA register based on the associated pin
  *_TCCRA = value;
}

void DigitalPin::setTCCRB(uint8_t value) {
  // Set TCCRB register based on the associated pin
  *_TCCRB = value;
}

void DigitalPin::setTCNT(uint16_t value) {
  // Set TCNT register based on the associated pin
  uint8_t high_byte, low_byte;
  switch(_pinNum) {
    case 13: case 4: case 10: case 9:
      low_byte = value & 0xFF;
      *_TCNT = value;
    break;

    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = (value >> 8);
      low_byte = value & 0xFF;
      *_TCNTH = high_byte;
      *_TCNTL = low_byte;
    break;
  }
}

void DigitalPin::setOCRA(uint16_t value) {
  // Set OCRA register based on the associated pin
  uint8_t high_byte, low_byte;
  switch(_pinNum) {
    case 13: case 4: case 10: case 9:
      low_byte = value & 0xFF;
      *_OCRA = value;
    break;

    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = (value >> 8);
      low_byte = value & 0xFF;
      *_OCRAH = high_byte;
      *_OCRAL = low_byte;
    break;    
  }
}

void DigitalPin::setOCRB(uint16_t value) {
  // Set OCRB register based on the associated pin
  uint8_t high_byte, low_byte;
  switch(_pinNum) {
    case 13: case 4: case 10: case 9:
      low_byte = value & 0xFF;
      *_OCRB = value;
    break;

    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = (value >> 8);
      low_byte = value & 0xFF;
      *_OCRBH = high_byte;
      *_OCRBL = low_byte;
    break;
  }
}

void DigitalPin::setOCRC(uint16_t value) {
  // Set OCRC register based on the associated pin
  // Timers 0, 2 do not feature an OCRC register
  uint8_t high_byte, low_byte;
  switch(_pinNum) {
    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = (value >> 8);
      low_byte = value & 0xFF;
      *_OCRCH = high_byte;
      *_OCRCL = low_byte;
    break;
  }
}

void DigitalPin::factorOCRA(float factor) {
  // Factor OCRA register based on the associated pin
  uint8_t high_byte, low_byte, value_high_byte, value_low_byte;
  uint16_t total, value;
  switch(_pinNum) {
    case 13: case 4: case 10: case 9:
      low_byte = *_OCRA;
      value = low_byte*factor;
      *_OCRA = value;
    break;

    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = *_OCRAH;
      low_byte = *_OCRAL;
      total = ((uint16_t)high_byte << 8) | low_byte;
      value = total*factor;
      value_high_byte = (value >> 8);
      value_low_byte = value & 0xFF;
      *_OCRAH = value_high_byte;
      *_OCRAL = value_low_byte;
    break;
  }
}

void DigitalPin::factorOCRB(float factor) {
  // Factor OCRB register based on the associated pin
  uint8_t high_byte, low_byte, value_high_byte, value_low_byte;
  uint16_t total, value;
  switch(_pinNum) {
    case 13: case 4: case 10: case 9:
      low_byte = *_OCRB;
      value = low_byte*factor;
      *_OCRB = value;
    break;

    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = *_OCRBH;
      low_byte = *_OCRBL;
      total = ((uint16_t)high_byte << 8) | low_byte;
      value = total*factor;
      value_high_byte = (value >> 8);
      value_low_byte = value & 0xFF;
      *_OCRBH = value_high_byte;
      *_OCRBL = value_low_byte;
    break;
  }
}

void DigitalPin::factorOCRC(float factor) {
  // Factor OCRC register based on the associated pin
  // Timers 0, 2 do not feature an OCRC register
  uint8_t high_byte, low_byte, value_high_byte, value_low_byte;
  uint16_t total, value;
  switch (_pinNum) {
    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:    
      high_byte = *_OCRCH;
      low_byte = *_OCRCL;
      total = ((uint16_t)high_byte << 8) | low_byte;
      value = total*factor;
      value_high_byte = (value >> 8);
      value_low_byte = value & 0xFF;
      *_OCRCH = value_high_byte;
      *_OCRCL = value_low_byte;
    break;
  }
}

void DigitalPin::setICR(uint16_t value) {
  // Set ICR register based on the associated pin  
  uint8_t high_byte, low_byte;
  switch(_pinNum) {
    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = (value >> 8);
      low_byte = value & 0xFF;
      *_ICRH = high_byte;
      *_ICRL = low_byte;
    break;
  }
}

void DigitalPin::setDutyCycle(float value) {
  uint8_t high_byte, low_byte, value_high_byte, value_low_byte;
  uint16_t total, factored;
  switch(_pinNum) {
    case 11: case 12: case 2: case 3: case 5: case 6: case 7: case 8: case 44: case 45: case 46:
      high_byte = *_ICRH;
      low_byte = *_ICRL;
      total = ((uint16_t)high_byte << 8) | low_byte;
      factored = static_cast<uint16_t>((total * (value / 100.0)) + 0.5);
      value_high_byte = (factored >> 8);
      value_low_byte = factored & 0xFF;
      *_OCRAH = value_high_byte;
      *_OCRAL = value_low_byte;      
  }
}

void DigitalPin::setTIMSK(uint8_t value) {
  // Set TIMSK register based on the associated pin
  *_TIMSK = value;
}